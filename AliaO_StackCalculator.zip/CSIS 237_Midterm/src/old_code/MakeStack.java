package old_code;

import stack_exceptions.*;

public class MakeStack {
	private double[] StackArray; 
	private int StackSize; 
	private int StackPtr; 
	
//constructors 	
	public MakeStack() {
		this.StackArray = new double [0]; 
	}//end default constructor 
	
	public MakeStack(int SetSize) {
		this.StackSize = SetSize; 
		this.StackPtr = -1; 
		this.StackArray = new double [StackSize]; 
	}//end alternate constructor, String Processing Mode
	
	
//methods
	public double peek() throws StackUnderflowException {
		if(isEmpty()) {
			throw new StackUnderflowException("Stack is empty. Nothing to return"); 
		}//end if statement
		else {
			return StackArray[StackPtr]; 
		}//end else statement
	}//end peek method
	
	public double pop() throws StackUnderflowException {
		if(isEmpty()) {
			throw new StackUnderflowException("Stack is empty. Can't return a value"); 
		}//end if statement
		else {
			return StackArray[StackPtr--]; 
		}//end else statement
	}//end pop method
	
	public void push(double E) throws StackOverflowException {
		if(isFull()) {
			throw new StackOverflowException("Stack is full. Can't enter a value"); 
		}//end if statement
		else {
			StackArray[++StackPtr] = E; 
		}//end else statement
	}//end push method
	
	public boolean isEmpty() {
		if(StackPtr == -1) {
			return true; 
		}//end if statement
		else {
			return false; 
		}//end else statement
	}//end isEmpty method
	
	public boolean isFull() {
		if(StackPtr == StackSize - 1) {
			return true; 
		}//end if statement
		else {
			return false; 
		}//end else statement
	}//end isFull method
	
	public void printStack() {
		System.out.println("Printing Stack...");
		int counter = StackSize - 1; 
		
		while(counter > StackPtr) {
			System.out.print("-Empty-" + "\t");
			-- counter; 
		}//end fist while loop
		
		while(counter >= 0) {
			System.out.print(StackArray[counter] + "\t");
			-- counter; 
		}//end second while loop
		
		System.out.println();
	}//end printStack method
}//end MakeStack method