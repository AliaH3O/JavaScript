package stack_exceptions;

public class OperatorFormatException extends Exception{
	public OperatorFormatException(String s){
		super(s);
	}//end constructor

}//end NumberFormatException class