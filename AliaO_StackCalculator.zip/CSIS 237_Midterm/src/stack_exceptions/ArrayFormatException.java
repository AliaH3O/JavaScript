package stack_exceptions;

public class ArrayFormatException extends Exception{
	public ArrayFormatException (String s){
		super(s);
	}//end constructor

}//end class OperandFormatException