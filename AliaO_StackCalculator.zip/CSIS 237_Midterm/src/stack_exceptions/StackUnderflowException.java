package stack_exceptions;

public class StackUnderflowException extends Exception{

	public StackUnderflowException(String m){
		super(m);
	}//end constructor
}//end class StackUnderflowException