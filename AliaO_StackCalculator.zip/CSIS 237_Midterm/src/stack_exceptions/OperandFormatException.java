package stack_exceptions;

public class OperandFormatException extends Exception{
	public OperandFormatException(String s){
		super(s);
	}//end constructor

}//end class ArrayFormatException