package stack_exceptions;

public class StackOverflowException extends Exception {
		
	public StackOverflowException(String s){
		super(s);
	}//end constructor
		
}//end StackOverflowException class