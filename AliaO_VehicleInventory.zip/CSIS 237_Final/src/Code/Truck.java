package Code;
import java.util.*; 

public class Truck extends Vehicle {
	private LinkedList <String> tVIN;		//Unique code that identifies the vehicle
	private LinkedList <Double> tMSRP; 		//Manufacturer's suggest retail price of the vehicle
	private LinkedList <String> tMake; 		//Manufacturer of the vehicle
	private LinkedList <String> tModel; 	//Model name of the vehicle
	private LinkedList <Integer> tModelYear;//Year the vehicle was made
	
//constructors
	public Truck(String aType, String aVIN, double aMSRP, String aMake, String aModel, int aModelYear) {
		super(aType);
		tVIN = new LinkedList <String>(); 
		tMSRP = new LinkedList <Double>();
		tMake = new LinkedList <String>(); 
		tModel = new LinkedList <String>(); 
		tModelYear = new LinkedList <Integer>(); 
		
		System.out.println("Truck entry created");
	}
	
//setters and getters
	
//methods
	public void addTruck (String aVIN, String aType, double aMSRP, String aMake, String aModel, int aModelYear) { 
		tVIN.addLast(aVIN);
		tMSRP.addLast(aMSRP);
		tMake.addLast(aMake); 
		tModel.addLast(aModel); 
		tModelYear.addLast(aModelYear);
		System.out.println("Temp confirm: Truck added");
	}
	
	public void printTruckInventory() {
		for (int i = 0; i < tVIN.size(); i++) {
			System.out.println("Truck at index " + i + ": " + tVIN.get(i) + ", $" + tMSRP.get(i) + " " + 
			tMake.get(i) + "-" + tModel.get(i) + ", " + tModelYear.get(i));
		}
	}
	
}//end class Truck