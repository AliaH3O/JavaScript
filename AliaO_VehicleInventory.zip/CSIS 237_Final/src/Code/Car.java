package Code;
import java.util.*; 

public class Car {
	private LinkedList <String> cType = new LinkedList <String>(); 			//Vehicle type: Car, Truck, or SUV
	private LinkedList <String> cVIN = new LinkedList <String>();			//Unique code that identifies the vehicle
	private LinkedList <Double> cMSRP = new LinkedList <Double>(); 			//Manufacturer's suggest retail price of the vehicle
	private LinkedList <String> cMake = new LinkedList <String>(); 			//Manufacturer of the vehicle
	private LinkedList <String> cModel = new LinkedList <String>(); 		//Model name of the vehicle
	private LinkedList <Integer> cModelYear = new LinkedList <Integer>();	//Year the vehicle was made
	
//constructors
	public Car(String aType, String aVIN, double aMSRP, String aMake, String aModel, int aModelYear) {
		cType.addLast(aType);
		cVIN.addLast(aVIN);
		cMSRP.addLast(aMSRP);
		cMake.addLast(aMake); 
		cModel.addLast(aModel); 
		cModelYear.addLast(aModelYear); 
		
		System.out.println("Car entry created");
	}
	
//setters and getters
	
	
}//end class Car