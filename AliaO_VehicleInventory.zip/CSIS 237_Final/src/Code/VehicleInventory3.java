package Code;
import java.util.*; 

public class VehicleInventory3 {
	public static Scanner console = new Scanner (System.in);
	public static void main (String[] args) throws Exception{
/*Driver Loop
You will create a CUI driver loop that will use the methods and data structure specified above so the user can manage the inventory. 
The program will produce an empty data structure to store vehicles. It will then prompt the user (using a sentinel loop) to choose an option. 
This will allow the user to interact with the inventory in real-time. 
*/
	 welcome(); 
	 openLot();  
	 
	}//end main method
	static LinkedList <Vehicle3> vList = new LinkedList <Vehicle3>();
	
	public static void welcome() {
		System.out.println("Welcome to the UWRF Dealership!"); 
	}//end welcome method
	
	
	public static void closeLot() {
		System.out.println("Goodbye!");
	}//end closeLot method
	
	
	public static void openLot() throws Exception {				//Need to update. Sentinel loop
		System.out.println("What would you like to do? Enter 'help' for options menu, enter 'exit' to leave");
		String answer = console.next(); 
		
		if (answer.equalsIgnoreCase("add")) {
			addVehicle();
		}
		else if (answer.equalsIgnoreCase("remove")) {
			removeMenu();  
		}
		else if(answer.equalsIgnoreCase("update")) {
			System.out.print("Enter the index of the vehicle you would like to update:");
			int uResponse = console.nextInt(); 
			updateVehicle(uResponse); 
		}
		else if(answer.equalsIgnoreCase("find")) {
			findMenu(); 
		}
		else if(answer.equalsIgnoreCase("print")) {
			printMenu(); 
		}
		else if (answer.equalsIgnoreCase("help")) {
			System.out.println("Enter 'add' to add a vehicle.\n" +
							   "Enter 'remove' to remove a vehicle.\n" + 
					           "Enter 'update' to update a vehicle.\n" + 
							   "Enter 'find' to find a vehicle.\n" + 
					           "Enter 'print' to print a list of vehicles in the lot.\n"); 
			openLot(); 
		}
		else if (answer.equalsIgnoreCase("exit")) {
			closeLot(); 
		}
		else 
			throw new Exception ("Please enter an accepted keyword"); 
	}//end openLot method
	
//Menu methods
	public static void removeMenu() throws Exception{
		System.out.println("How would you like to remove the vehicle? Enter 'help' for options menu, enter 'exit' to go back");
		System.out.print("Remove by: ");
		String removeResponse = console.next(); 
		
		if (removeResponse.equalsIgnoreCase("Index")) { 
			removeByIndex(); 
		}
		else if (removeResponse.equalsIgnoreCase("VIN")) {
			removeByVIN(); 
		}
		else if (removeResponse.equalsIgnoreCase("help")) {
			System.out.println("Enter 'index' to remove a vehicle by index.\n" +
							   "Enter 'VIN' to remove a vehicle by VIN number.\n" +
							   "Enter 'exit' to return to previous menu.");
			removeMenu(); 
		}
		else if (removeResponse.equalsIgnoreCase("exit")) {
			openLot(); 
		}
		else
			throw new Exception ("Please enter an accepted keyword"); 
	}//end removeMenu method
	
	
	public static void findMenu() throws Exception{
		System.out.println("How would you like to find the vehicle? Separate parameters with a comma (,)" + 
						   "Enter 'help' for options menu, enter 'exit' to go back");
		System.out.print("Find by: ");
		String findResponse = console.next(); 
		
		if(findResponse.equalsIgnoreCase("VIN")) {
			findByVIN(); 
		}
		else if(findResponse.equalsIgnoreCase("Type")) {
			findByType(); 
		}
		else if (findResponse.equalsIgnoreCase("Cheapest")) {
			findByCheapest(); 
		}
		else if(findResponse.equalsIgnoreCase("Range")) {
			findByRange(); 
		}
		else if(findResponse.equalsIgnoreCase("Type, Cheapest") || findResponse.equalsIgnoreCase("Cheapest, Type")) {
			findByTypeCheapest(); 
		}
		else if(findResponse.equalsIgnoreCase("Type, Range") || findResponse.equalsIgnoreCase("Range, Type")) {
			findByTypeRange(); 
		}
		else if(findResponse.equalsIgnoreCase("help")) {
			System.out.println("Enter 'VIN' to find a vehicle by VIN number.\n" +
					   		   "Enter 'Type' to find a vehicle by type.\n" +
					   		   "Enter 'Cheapest' to find a vehicle by cheapest price.\n" +
					   		   "Enter 'Range' to find a vehicle by range of MSRP.\n" +
					   		   "Enter 'Type, Cheapest' to find a vehicle by type and cheapest price.\n" +
					   		   "Enter 'Type, Range' to find a vehicle by type and range of MSRP.\n" +
					           "Enter 'exit' to return to previous menu.");
			findMenu(); 
		}
		else if(findResponse.equalsIgnoreCase("exit")) {
			openLot(); 
		}
		else 
			throw new Exception("Please enter an accepted keyword"); 
	}//end findMenu method
	
	
	
	public static void printMenu() throws Exception{
		System.out.println("How would you like to print the vehicle inventory?  Enter 'help' for options menu, enter 'exit' to go back");
		System.out.print("Print by: ");
		String pResponse = console.next(); 
		
		if(pResponse.equalsIgnoreCase("All")) {
			printAllInventory(); 
		}
		else if(pResponse.equalsIgnoreCase("Type")) {
			printTypeInventory(); 
		}
		else if(pResponse.equalsIgnoreCase("VIN")) {
			printVehicleByVIN(); 
		}
		else if(pResponse.equalsIgnoreCase("Index")) {
			printVehicleByIndex(); 
		}
		else if(pResponse.equalsIgnoreCase("help")) {
			System.out.println("Enter 'All' to print all vehicles in lot inventory.\n" +
							   "Enter 'Type' to print all vehicles of a certain type.\n" +
							   "Enter 'VIN' to print a single vehicle with the specified VIN number.\n" +
							   "Enter 'Index' tp print a singe vehicle listed at specified inventory index.\n");
			printMenu(); 
		}
		else if(pResponse.equalsIgnoreCase("exit")) {
			openLot(); 
		}
		else
			throw new Exception("Please enter an accepted keyword"); 
	}//end printMenu method
	
	
//Active methods
	public static void addVehicle() throws Exception {
		System.out.println("Enter the information of the vehicle you would like to include.");
		System.out.println("Enter vehicle type: ");
		String type = console.next(); 
		if (!(type.equalsIgnoreCase("car") || type.equalsIgnoreCase("truck") || type.equalsIgnoreCase("suv"))) {
			throw new Exception ("Please enter a vehicle type of Car, Truck, or SUV"); 
		}
		
		System.out.println("Enter vehicle VIN number: ");
		String VIN = console.next(); 
		
		System.out.println("Enter vehicle MSRP: ");
		double MSRP = console.nextDouble();
		
		System.out.println("Enter vehicle make: ");
		String make = console.next(); 
		
		System.out.println("Enter vehicle model: ");
		String model = console.next(); 
		
		System.out.println("Enter vehicle model year: ");
		int modelYear = console.nextInt(); 
		
		Vehicle3 vehicle1 = new Vehicle3(type, VIN, MSRP, make, model, modelYear); 
		vList.addLast(vehicle1);
		
		System.out.println("Would you like to add another vehicle? Enter 'yes' or 'no'");
		String addResponse = console.next(); 
		
		if(addResponse.equalsIgnoreCase("yes")) {
			addVehicle(); 
		}
		else
			openLot(); 
	}//end addVehcile method
	
	
	public static void updateVehicle(int iUpdate) throws Exception {
		System.out.println("Testing line: Unfinished method");
		
		System.out.println("Would you like to remove another vehicle? Enter 'yes' or 'no'");
		String rAnswer = console.next(); 
		if (rAnswer.equalsIgnoreCase("yes")) {
			removeMenu(); 
		}
		else
			openLot(); 
	}//end updateVehcile method
	
//remove methods
	public static void removeByIndex() throws Exception{
		System.out.println("Enter the index of the vechile:");
		int rIndex = console.nextInt();
		if (rIndex >= vList.size() || rIndex < 0) {
			throw new Exception("Index out of bounds for lot inventory."); 
		}
		else {
			vList.remove(rIndex); 
			System.out.println("Vehicle removed from lot");
		}
		
		System.out.println("Would you like to remove another vehicle? Enter 'yes' or 'no'");
		String rAnswer = console.next(); 
		if (rAnswer.equalsIgnoreCase("yes")) {
			removeMenu(); 
		}
		else {
			openLot(); 
		}
	}//end removeByIndex method
	
	
	public static void removeByVIN() throws Exception{
		System.out.println("Enter the VIN number of the vehicle you want to remove: ");
		String rVIN = console.next();
		Iterator<Vehicle3> rItr = vList.descendingIterator();
		
		System.out.println("Testing line: Unfinished method");
		
		System.out.println("Would you like to remove another vehicle? Enter 'yes' or 'no'");
		String rAnswer = console.next(); 
		if (rAnswer.equalsIgnoreCase("yes")) {
			removeMenu(); 
		}
		else {
			openLot(); 
		}
	}//end removeByVIN method
	
//find methods
	public static void findByVIN() throws Exception {
		System.out.println("Testing line: Unfinished method");
		
		System.out.println("Would you like to find another vehicle? Enter 'yes' or 'no'");
		String fAnswer = console.next(); 
		if (fAnswer.equalsIgnoreCase("yes")) {
			findMenu(); 
		}
		else
			openLot();
	}//end findByVIN method
	
	
	public static void findByType() throws Exception {
		System.out.println("Testing line: Unfinished method");
		
		System.out.println("Would you like to find another vehicle? Enter 'yes' or 'no'");
		String fAnswer = console.next(); 
		if (fAnswer.equalsIgnoreCase("yes")) {
			findMenu(); 
		}
		else
			openLot();
	}//end findByType method
	
	
	public static void findByCheapest() throws Exception {
		System.out.println("Testing line: Unfinished method");
		
		System.out.println("Would you like to find another vehicle? Enter 'yes' or 'no'");
		String fAnswer = console.next(); 
		if (fAnswer.equalsIgnoreCase("yes")) {
			findMenu(); 
		}
		else
			openLot();
	}//end findByCheapeset method
	
	
	public static void findByRange() throws Exception {
		System.out.println("Testing line: Unfinished method");
		
		System.out.println("Would you like to find another vehicle? Enter 'yes' or 'no'");
		String fAnswer = console.next(); 
		if (fAnswer.equalsIgnoreCase("yes")) {
			findMenu(); 
		}
		else
			openLot();
	}//end findByRange method
	
	
	public static void findByTypeCheapest() throws Exception {
		System.out.println("Testing line: Unfinished method");
		
		System.out.println("Would you like to find another vehicle? Enter 'yes' or 'no'");
		String fAnswer = console.next(); 
		if (fAnswer.equalsIgnoreCase("yes")) {
			findMenu(); 
		}
		else
			openLot();
	}//end findByTypeCheapest method
	
	
	public static void findByTypeRange() throws Exception {
		System.out.println("Testing line: Unfinished method");
		
		System.out.println("Would you like to find another vehicle? Enter 'yes' or 'no'");
		String fAnswer = console.next(); 
		if (fAnswer.equalsIgnoreCase("yes")) {
			findMenu(); 
		}
		else
			openLot();
	}//end findByTypeRange method
	
//print methods
	public static void printAllInventory() throws Exception {
		Iterator<Vehicle3> pItr = vList.descendingIterator();
		while(pItr.hasNext()) {
			System.out.println(pItr.next());
		}
		
		System.out.println("Would you like to print inventory again? Enter 'yes' or 'no'");
		String pAnswer = console.next(); 
		if (pAnswer.equalsIgnoreCase("yes")) {
			printMenu(); 
		}
		else
			openLot();
	}//end printAllInventory method
	
	
	public static void printTypeInventory() throws Exception {
		System.out.println("Enter the type of vehicles you want to print: ");
		String pType = console.next(); 
		
		System.out.println("Testing line: Unfinished method");
		
		System.out.println("Would you like to print inventory again? Enter 'yes' or 'no'");
		String pAnswer = console.next(); 
		if (pAnswer.equalsIgnoreCase("yes")) {
			printMenu(); 
		}
		else
			openLot();
	}//end printTypeInventory method
	
	
	public static void printVehicleByVIN() throws Exception {
		System.out.println("Enter the VIN of the vehicle: ");
		String pVIN = console.next(); 
		
		System.out.println("Testing line: Unfinished method");
		
		System.out.println("Would you like to print inventory again? Enter 'yes' or 'no'");
		String pAnswer = console.next(); 
		if (pAnswer.equalsIgnoreCase("yes")) {
			printMenu(); 
		}
		else
			openLot();
	}//end printVehicleByVIN method
	
	
	public static void printVehicleByIndex() throws Exception {
		System.out.print("Enter the inventory index of the vehicle: ");
		int pIndex = console.nextInt(); 
		if (pIndex >= vList.size() || pIndex < 0) {
			throw new Exception("Index out of bounds for lot inventory."); 
		}
		else
			System.out.println(vList.get(pIndex)); 
		
		System.out.println("Would you like to print inventory again? Enter 'yes' or 'no'");
		String pAnswer = console.next(); 
		if (pAnswer.equalsIgnoreCase("yes")) {
			printMenu(); 
		}
		else
			openLot();
	}//end printVehicleByIndex method
}//end class VehicleInventory