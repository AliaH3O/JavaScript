package Code;
import java.util.*; 

public class SUV extends Vehicle {
	private LinkedList <String> sVIN;		//Unique code that identifies the vehicle
	private LinkedList <Double> sMSRP; 		//Manufacturer's suggest retail price of the vehicle
	private LinkedList <String> sMake; 		//Manufacturer of the vehicle
	private LinkedList <String> sModel; 	//Model name of the vehicle
	private LinkedList <Integer> sModelYear;//Year the vehicle was made
	
//constructors
	public SUV(String aType, String aVIN, double aMSRP, String aMake, String aModel, int aModelYear) {
		super(aType);
		sVIN = new LinkedList <String>(); 
		sMSRP = new LinkedList <Double>();
		sMake = new LinkedList <String>(); 
		sModel = new LinkedList <String>(); 
		sModelYear = new LinkedList <Integer>(); 
		
		System.out.println("SUV entry created");
	}
	
//setters and getters
	
//methods
	public void addSUV (String aVIN, String aType, double aMSRP, String aMake, String aModel, int aModelYear) { 
		sVIN.addLast(aVIN);
		sMSRP.addLast(aMSRP);
		sMake.addLast(aMake); 
		sModel.addLast(aModel); 
		sModelYear.addLast(aModelYear);
		System.out.println("Temp confirm: SUV added");
	}
	
	public void printSUVInventory() {
		for (int i = 0; i < sVIN.size(); i++) {
			System.out.println("SUV at index " + i + ": " + sVIN.get(i) + ", $" + sMSRP.get(i) + " " + 
			sMake.get(i) + "-" + sModel.get(i) + ", " + sModelYear.get(i));
		}
	}
}//end class SUV