package Code2;
import java.util.*; 

public class Vehicle2{
	private LinkedList <String> Type; 		//Vehicles come in 3 types: Car, Truck, or SUV
	private LinkedList <String> VIN;		//Unique code that identifies the vehicle
	private LinkedList <Double> MSRP; 		//Manufacturer's suggest retail price of the vehicle
	private LinkedList <String> Make; 		//Manufacturer of the vehicle
	private LinkedList <String> Model; 		//Model name of the vehicle
	private LinkedList <Integer> ModelYear;//Year the vehicle was made
	
//constructors
	public Vehicle2() {
		Type = new LinkedList <String>(); 
		VIN = new LinkedList <String>(); 
		MSRP = new LinkedList <Double>();
		Make = new LinkedList <String>(); 
		Model = new LinkedList <String>(); 
		ModelYear = new LinkedList <Integer>();
	}
	
	public void addVehicle2(String aType, String aVIN, double aMSRP, String aMake, String aModel, int aModelYear) {
		Type.addLast(aType); 
		VIN.addLast(aVIN);
		MSRP.addLast(aMSRP);
		Make.addLast(aMake);
		Model.addLast(aModel); 
		ModelYear.addLast(aModelYear); 
		
		System.out.println("Car entry created");
	}
	
//setters and getters
	
	
}//end class Car